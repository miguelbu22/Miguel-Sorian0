# get-string-length

NOTE: YOU SHOULD NOT CHANGE THE TEST FILE \*.test.js. IF YOU CHANGE IT, YOU WILL RECEIVE 0 POINTS.

**TODO: EDIT THIS README and ADD YOUR NAME IN THE FOLLOWING FILE:**

**Miguel:**

**Soriano:**

Open the file `get-string-length.js` and solve all of the TODOs specified in that file.

To run the test, type in the Terminal:

```
npm test
```
